package com.mycompany.torrehanoi;

import java.util.Stack;

public class TorreHanoi {
    
    public static void main(String[] args) {
         TorreHanoi s = new TorreHanoi();
		 int a = s.hanoiProblem(2, "IZQUIERDA", "MEDIO", "DERECHA");
		 System.out.println("SE MOVERÁ  " + a + "  PASOS.");
         
    }
    
    public enum Action{
        No, IToM, MToI, MtoD, DToM//Describe las cuatros acciones: de izq a centro, de centro a izquierda,
                            //de centro a derecha, de derecha a centro
    }
    
    public static int hanoiProblem(int num, String izquierda, String medio, String derecha){
        Stack<Integer> ls = new Stack<Integer>();
        Stack<Integer> ms = new Stack<Integer>();
        Stack<Integer> rs = new Stack<Integer>();
        ls.push(Integer.MAX_VALUE);
        ms.push(Integer.MAX_VALUE);
        rs.push(Integer.MAX_VALUE);
        for( int i = num; i>0; i--){
            ls.push(i); //La pila de la izquierda simula la colocación de discos, 
                       //con el grande abajo y el pequeño arriba
            
        }
   
        Action[] record = {Action.No};
        int step = 0;
        //Si la cantidad almacenada en el lado derecho de la pila no llega a num + 1, 
        //significa que no se ha movido por todas partes, y luego ejecuta el ciclo
            while (rs.size()!= num +1){ 
            step += fStackTotStack(record, Action.MToI, Action.IToM,ls, ms,izquierda, derecha);
            step += fStackTotStack(record, Action.IToM, Action.MToI,ms, ls,medio, izquierda);
            step += fStackTotStack(record, Action.DToM, Action.MtoD,ms, rs,medio, derecha);
            step += fStackTotStack(record, Action.MtoD, Action.DToM,rs, ms,derecha, medio);
            }
        return step;
        
    }
    
    public static int fStackTotStack(Action[] record, Action preNoAct,
            Action nowAct,Stack<Integer>fStack,Stack<Integer> tStack,String from, String to){
        if (record[0]!= preNoAct && fStack.peek()<tStack.peek()){
            tStack.push(fStack.pop());
            System.out.println("MUEVE   "+tStack.peek()+"   DE   "+from+"   A   "+to);
            record [0]= nowAct;
            return 1;
            
        }
        return 0;
    }
}
